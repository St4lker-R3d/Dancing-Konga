package shx.cotacaodolar.controller;

import java.io.IOException;
import java.net.MalformedURLException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Date;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import shx.cotacaodolar.model.Moeda;
import shx.cotacaodolar.service.MoedaService;


@RestController
@RequestMapping(value = "/")
public class MoedaController {

    @Autowired
    private MoedaService moedaService;

    @GetMapping("/moeda/{data1}&{data2}")
    public List<Moeda> getCotacoesPeriodo(@PathVariable("data1") String startDate, @PathVariable("data2") String endDate) throws IOException, MalformedURLException, ParseException{
        return moedaService.getCotacoesPeriodo(startDate, endDate);
    }
    
    @GetMapping("/moeda/atual")
    public List<Moeda> getCotacaoAtual() throws IOException, MalformedURLException, ParseException{
         return moedaService.getCotacaoAtual();
    }
    
    @GetMapping("/moeda/menor/{data1}&{data2}")
    public List<Moeda> getCotacoesMenoresAtual(@PathVariable("data1") String startDate, @PathVariable("data2") String endDate) throws IOException, MalformedURLException, ParseException{
         return moedaService.getCotacoesMenoresAtual(startDate, endDate);
    }
    
    @GetMapping("/moeda/todos")
    public Map<String, List<Moeda>> getCotacoesCompletas() throws IOException, MalformedURLException, ParseException {
        // Obtém a data atual no formato MM-dd-yyyy
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
        String currentDate = dateFormat.format(new Date());

        Map<String, List<Moeda>> resultados = new HashMap<>();
        resultados.put("cotacoesPeriodo", moedaService.getCotacoesPeriodo(currentDate, currentDate));
        resultados.put("cotacaoAtual", moedaService.getCotacaoAtual());
        resultados.put("cotacoesMenoresAtual", moedaService.getCotacoesMenoresAtual(currentDate, currentDate));
        return resultados;
    }

}
