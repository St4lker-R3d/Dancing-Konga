package shx.cotacaodolar.service;

import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import shx.cotacaodolar.model.Moeda;
import shx.cotacaodolar.model.Periodo;

@Service
public class MoedaService {

    private String getCurrentDate() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
        return dateFormat.format(new Date());
    }

    private List<Moeda> fetchCotacoes(String url) throws IOException, ParseException {
        URL apiUrl = new URL(url);
        HttpURLConnection connection = (HttpURLConnection) apiUrl.openConnection();
        connection.setRequestMethod("GET");

        try (InputStream inputStream = connection.getInputStream();
             InputStreamReader reader = new InputStreamReader(inputStream)) {

            JsonArray cotacoesArray = JsonParser.parseReader(reader)
                    .getAsJsonObject()
                    .getAsJsonArray("value");

            List<Moeda> moedasLista = new ArrayList<>();

            for (JsonElement obj : cotacoesArray) {
                Date data = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
                        .parse(obj.getAsJsonObject().get("dataHoraCotacao").getAsString());

                Moeda moedaRef = new Moeda();
                moedaRef.preco = obj.getAsJsonObject().get("cotacaoCompra").getAsDouble();
                moedaRef.data = new SimpleDateFormat("dd/MM/yyyy").format(data);
                moedaRef.hora = new SimpleDateFormat("HH:mm:ss").format(data);
                moedasLista.add(moedaRef);
            }
            return moedasLista;
        } finally {
            connection.disconnect(); 
        }
    }

    public List<Moeda> getCotacoesPeriodo(String startDate, String endDate) throws IOException, ParseException {
        Periodo periodo = new Periodo(startDate, endDate);

        String urlString = "https://olinda.bcb.gov.br/olinda/servico/PTAX/versao/v1/odata/CotacaoDolarPeriodo(dataInicial=@dataInicial,dataFinalCotacao=@dataFinalCotacao)?%40dataInicial='" + periodo.getDataInicial() + "'&%40dataFinalCotacao='" + periodo.getDataFinal() + "'&%24format=json&%24skip=0&%24top=" + periodo.getDiasEntreAsDatasMaisUm();

        return fetchCotacoes(urlString);
    }

    public List<Moeda> getCotacaoAtual() throws IOException, ParseException {
        String url = "https://olinda.bcb.gov.br/olinda/servico/PTAX/versao/v1/odata/CotacaoDolarDia(dataCotacao=@dataCotacao)?%40dataCotacao='"
                + getCurrentDate() + "'&%24format=json";

        return fetchCotacoes(url);
    }

    public List<Moeda> getCotacoesMenoresAtual(String startDate, String endDate) throws IOException, ParseException {
        // Obter a cotação atual
        List<Moeda> cotacaoAtual = getCotacaoAtual();
        double cotacaoAtualValue = cotacaoAtual.isEmpty() ? 0.0 : cotacaoAtual.get(0).preco;
        List<Moeda> cotacoesPeriodo = getCotacoesPeriodo(startDate, endDate);
        List<Moeda> cotacoesMenoresAtual = cotacoesPeriodo.stream()
                .filter(moeda -> moeda.preco < cotacaoAtualValue)
                .collect(Collectors.toList());
        
        if (cotacoesMenoresAtual.isEmpty()) {
            System.out.println("Nenhuma cotação menor que a cotação atual foi encontrada.");
        }
        
        return cotacoesMenoresAtual;
    }
}
